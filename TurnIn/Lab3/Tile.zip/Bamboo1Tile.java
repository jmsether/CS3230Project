package com.sethy;

public class Bamboo1Tile extends PictureTile {
    public Bamboo1Tile() {
        super("Sparrow");
    }

    public String toString(){
        return "Bamboo 1";
    }
}

