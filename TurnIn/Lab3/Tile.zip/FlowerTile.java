package com.sethy;

public class FlowerTile extends PictureTile{
    public FlowerTile(String name){
        super(name);
    }

    @Override
    public String toString() {
        return "FlowerTile";
    }
}
